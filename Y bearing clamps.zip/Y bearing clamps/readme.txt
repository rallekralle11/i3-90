solid is a basic zip-tie based clamp
the autoaligning has a ridge in the middle which lets the bearing align itself to the rod
the alignable ones have wider screw holes that let it slide a couple milimeters side to side
i'd recommend using alignable_solid, the others are just here for experimenting with